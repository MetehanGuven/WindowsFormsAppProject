﻿namespace WindowsFormsAppProject
{
    partial class FormProfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormProfile));
            this.button1 = new System.Windows.Forms.Button();
            this.lbluser = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblemail = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lblname = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.lblphone = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.lbladdr = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.lblcity = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.lblcntry = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.lblpass = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(809, 485);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 39);
            this.button1.TabIndex = 0;
            this.button1.Text = "Upgrade";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbluser.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbluser.Location = new System.Drawing.Point(638, 118);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(94, 20);
            this.lbluser.TabIndex = 1;
            this.lbluser.Text = "Username";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(753, 116);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(167, 22);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(753, 156);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(167, 22);
            this.textBox2.TabIndex = 4;
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblemail.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblemail.Location = new System.Drawing.Point(663, 432);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(66, 20);
            this.lblemail.TabIndex = 3;
            this.lblemail.Text = "E_mail";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(753, 196);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(167, 22);
            this.textBox3.TabIndex = 6;
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblname.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblname.Location = new System.Drawing.Point(591, 198);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(141, 20);
            this.lblname.TabIndex = 5;
            this.lblname.Text = "Name_Surname";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(753, 238);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(167, 22);
            this.textBox4.TabIndex = 8;
            // 
            // lblphone
            // 
            this.lblphone.AutoSize = true;
            this.lblphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblphone.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblphone.Location = new System.Drawing.Point(596, 240);
            this.lblphone.Name = "lblphone";
            this.lblphone.Size = new System.Drawing.Size(136, 20);
            this.lblphone.TabIndex = 7;
            this.lblphone.Text = "Phone_Number";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(753, 277);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(167, 63);
            this.textBox5.TabIndex = 10;
            // 
            // lbladdr
            // 
            this.lbladdr.AutoSize = true;
            this.lbladdr.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbladdr.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbladdr.Location = new System.Drawing.Point(654, 277);
            this.lbladdr.Name = "lbladdr";
            this.lbladdr.Size = new System.Drawing.Size(78, 20);
            this.lbladdr.TabIndex = 9;
            this.lbladdr.Text = "Address";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(753, 353);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(167, 22);
            this.textBox6.TabIndex = 12;
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblcity.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblcity.Location = new System.Drawing.Point(687, 355);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(42, 20);
            this.lblcity.TabIndex = 11;
            this.lblcity.Text = "City";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(753, 391);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(167, 22);
            this.textBox7.TabIndex = 14;
            // 
            // lblcntry
            // 
            this.lblcntry.AutoSize = true;
            this.lblcntry.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblcntry.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblcntry.Location = new System.Drawing.Point(655, 393);
            this.lblcntry.Name = "lblcntry";
            this.lblcntry.Size = new System.Drawing.Size(74, 20);
            this.lblcntry.TabIndex = 13;
            this.lblcntry.Text = "Country";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(753, 430);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(167, 22);
            this.textBox8.TabIndex = 16;
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblpass.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblpass.Location = new System.Drawing.Point(641, 158);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(91, 20);
            this.lblpass.TabIndex = 15;
            this.lblpass.Text = "Password";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "back_button.png");
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Purple;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.ImageKey = "back_button.png";
            this.button2.ImageList = this.imageList1;
            this.button2.Location = new System.Drawing.Point(129, 44);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 94);
            this.button2.TabIndex = 17;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FormProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Purple;
            this.ClientSize = new System.Drawing.Size(1443, 647);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.lblcntry);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.lbladdr);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.lblphone);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbluser);
            this.Controls.Add(this.button1);
            this.Name = "FormProfile";
            this.Text = "FormProfile";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label lbluser;
        public System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox textBox2;
        public System.Windows.Forms.Label lblemail;
        public System.Windows.Forms.TextBox textBox3;
        public System.Windows.Forms.Label lblname;
        public System.Windows.Forms.TextBox textBox4;
        public System.Windows.Forms.Label lblphone;
        public System.Windows.Forms.TextBox textBox5;
        public System.Windows.Forms.Label lbladdr;
        public System.Windows.Forms.TextBox textBox6;
        public System.Windows.Forms.Label lblcity;
        public System.Windows.Forms.TextBox textBox7;
        public System.Windows.Forms.Label lblcntry;
        public System.Windows.Forms.TextBox textBox8;
        public System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button button2;
    }
}