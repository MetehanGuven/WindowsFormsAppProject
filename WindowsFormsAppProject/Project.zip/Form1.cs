﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsAppProject
{
    public partial class LogSc : Form
    {
        public LogSc()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, EventArgs e)
        {
            if (user.Text == "kullanıcı" && pass.Text == "kullanıcı")
            {
                new Main().Show();
                this.Hide();
            }
            else if (user.Text == "admin" && pass.Text == "admin")
            {
                new Main().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Kullanıcı adı veya şifre hatalıdır!!");
            }
        }

        private void pass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Login.PerformClick();
            }
        }

        private void EntSc_Load(object sender, EventArgs e)
        {
            this.AcceptButton = this.Login;
        }
    }
}
