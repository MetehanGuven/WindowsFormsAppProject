﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppProject
{
    public partial class Dif : Form
    {
        public Dif()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            new Main().Show();
            this.Hide();
        }
    }
}
